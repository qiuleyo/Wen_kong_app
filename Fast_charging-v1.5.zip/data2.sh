warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
  echo 300000000 > /sys/class/power_supply/battery/fast_charge_current
  echo 300000000 > /sys/class/power_supply/battery/thermal_input_current
  echo 300000000 > /sys/class/power_supply/usb/current_max
sleep 2s
data=`[[ -f $warm ]] && cat $warm`
if [[ $data -le 750 ]]; then
  echo '300000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "750" ]&&[ "$data" -lt "753" ];then
  echo '300000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "753" ]&&[ "$data" -lt "756" ];then
  echo '300000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "756" ]&&[ "$data" -lt "759" ];then
  echo '300000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "759" ]&&[ "$data" -lt "761" ];then
  echo '200000000' > "/sys/class/power_supply/battery/constant_charge_current_max" 
  elif [ "$data" -ge "761" ]&&[ "$data" -lt "763" ];then
  echo '150000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "763" ]&&[ "$data" -lt "765" ];then
  echo '100000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "765" ]&&[ "$data" -lt "767" ];then
  echo '50000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "767" ]&&[ "$data" -lt "769" ];then
  echo '10000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "769" ]&&[ "$data" -lt "771" ];then
  echo '1000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
fi
done
