SKIPUNZIP=0
REPLACE=""
echo " "
echo " 本模块属于魔改快充"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
