#!/system/bin/sh
/sbin/magisk su -c 'sh /data/adb/modules/Fast_charging/data1.sh'
/sbin/magisk su -c 'sh /data/adb/modules/Fast_charging/data2.sh'
/sbin/magisk su -c 'sh /data/adb/modules/Fast_charging/data3.sh'