MODDIR=${0%/*}
Fast_charging=/sys/class/power_supply/battery/input_suspend
Fast_charging2=/sys/class/power_supply/battery/charging_enabled
Start=800
Stop=1000
Delay=60s
Set_Greedy_Time=1
[[ ! -f $Fast_charging && ! -f $Fast_charging2 ]] && exit 1
until [[ $jslx == true ]]; do
[[ -n $Delay ]] && sleep $Delay
Status=`[[ -f $Fast_charging ]] && cat $Fast_charging`
Status2=`[[ -f $Fast_charging2 ]] && cat $Fast_charging2`
if [[ $(dumpsys battery|awk '/temperature/{print $2}') -le $Start ]]; then
  if [[ $Status -eq 1 || $Status2 -eq 0 ]]; then
 if [[ -n $D ]]; then
D=$D
elif [[ -z $D ]]; then
[[ -f $Fast_charging ]] && echo 0 >$Fast_charging
[[ -f $Fast_charging2 ]] && echo 1 >$Fast_charging2
D=1
unset C
 fi
  fi
elif [[ $(dumpsys battery|awk '/temperature/{print $2}') -ge $Stop ]]; then
   if [[ $Status -eq 0 || $Status2 -eq 1 ]]; then
 if [[ -n $C ]]; then
C=$C
elif [[ -z $C ]]; then
[[ -n $Set_Greedy_Time ]] && sleep $Set_Greedy_Time
[[ -f $Fast_charging ]] && echo 1 >$Fast_charging
[[ -f $Fast_charging2 ]] && echo 0 >$Fast_charging2
C=1
unset D
 fi
  fi
fi
done
