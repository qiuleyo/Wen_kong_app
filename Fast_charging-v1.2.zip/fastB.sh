warm="/sys/class/power_supply/battery/temp"
until [[ $jslx == true ]]; do
  echo 45000000 > /sys/class/power_supply/battery/fast_charge_current
  echo 45000000 > /sys/class/power_supply/battery/thermal_input_current
  echo 45000000 > /sys/class/power_supply/usb/current_max
sleep 2s
data=`[[ -f $warm ]] && cat $warm`
if [[ $data -le 800 ]]; then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "800" ]&&[ "$data" -lt "853" ];then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "853" ]&&[ "$data" -lt "856" ];then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "856" ]&&[ "$data" -lt "859" ];then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "859" ]&&[ "$data" -lt "861" ];then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max" 
  elif [ "$data" -ge "861" ]&&[ "$data" -lt "863" ];then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "863" ]&&[ "$data" -lt "865" ];then
  echo '45000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "865" ]&&[ "$data" -lt "868" ];then
  echo '35000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "868" ]&&[ "$data" -lt "869" ];then
  echo '2000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
  elif [ "$data" -ge "869" ]&&[ "$data" -lt "881" ];then
  echo '15000000' > "/sys/class/power_supply/battery/constant_charge_current_max"
fi
done
