pm enable com.xiaomi.joyose
pm enable com.miui.powerkeeper
pm enable com.xiaomi.powerchecker
echo "- 已解冻"