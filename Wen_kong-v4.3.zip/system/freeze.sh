pm disable com.xiaomi.joyose
pm disable com.miui.powerkeeper
pm disable com.xiaomi.powerchecker
echo "- 已冻结温控三件套"