SKIPUNZIP=0
REPLACE=""
echo "已安装"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  ui_print "install..."
