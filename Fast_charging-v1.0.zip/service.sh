#!/system/bin/sh
/sbin/magisk su -c 'sh /data/adb/modules/Fast_charging/fastA.sh'
/sbin/magisk su -c 'sh /data/adb/modules/Fast_charging/fastB.sh'
/sbin/magisk su -c 'sh /data/adb/modules/Fast_charging/fastC.sh'